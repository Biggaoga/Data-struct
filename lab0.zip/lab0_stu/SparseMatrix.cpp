#include <fstream>
#include <stdexcept>

#include "SparseMatrix.h"

SparseMatrix::SparseMatrix(const std::string input_file) {
  /* TODO: Your code here. */
}

void SparseMatrix::to_file(const std::string output_file) {
  /* TODO: Your code here. */
}

SparseMatrix SparseMatrix::operator*(const SparseMatrix &right) {
  /* TODO: Your code here. */
  return SparseMatrix();
}